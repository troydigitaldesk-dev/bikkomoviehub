import { createBikkoMhHandler } from "./lib/handler-core.mjs";

export { createBikkoMhHandler };

export async function handler(event, context) {
  const { getStore } = await import("@netlify/blobs");
  const run = createBikkoMhHandler({ getStore, env: process.env });
  return run(event, context);
}