import assert from "node:assert/strict";
import test from "node:test";
import { createBikkoMhHandler } from "../netlify/functions/lib/handler-core.mjs";

const testEnv = {
  BIKKO_MH_ACCESS_CODE: "bikko-test-access",
  SESSION_SECRET: "test-session-secret-that-is-long-enough-for-signing",
};
const fixedTime = new Date("2026-10-04T10:00:00.000Z");

function createFakeStore(initialState) {
  const records = new Map();
  let version = 0;
  if (initialState) {
    version += 1;
    records.set("shop-state-v1", {
      data: structuredClone(initialState),
      etag: `etag-${version}`,
    });
  }

  return {
    async getWithMetadata(key, options) {
      assert.deepEqual(options, { type: "json" });
      const record = records.get(key);
      return record
        ? { data: structuredClone(record.data), etag: record.etag, metadata: {} }
        : null;
    },
    async setJSON(key, value, options = {}) {
      const current = records.get(key);
      if (options.onlyIfNew && current) {
        return { modified: false, etag: current.etag };
      }
      if (options.onlyIfMatch !== undefined && current?.etag !== options.onlyIfMatch) {
        return { modified: false, etag: current?.etag };
      }
      version += 1;
      const etag = `etag-${version}`;
      records.set(key, { data: structuredClone(value), etag });
      return { modified: true, etag };
    },
  };
}

function createTestApp({ env = testEnv, initialState } = {}) {
  const store = createFakeStore(initialState);
  const storeOptions = [];
  const handler = createBikkoMhHandler({
    getStore(options) {
      storeOptions.push(options);
      return store;
    },
    env,
    now: () => new Date(fixedTime),
  });
  return { handler, storeOptions };
}

function request(method, path, { body, cookie, origin = "https://shop.netlify.app" } = {}) {
  return {
    path,
    httpMethod: method,
    headers: {
      host: "shop.netlify.app",
      origin,
      ...(body === undefined ? {} : { "content-type": "application/json" }),
      ...(cookie ? { cookie } : {}),
    },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
  };
}

function responseBody(response) {
  return JSON.parse(response.body);
}

async function signIn(handler) {
  const response = await handler(request("POST", "/api/bikko-mh/session", {
    body: { code: testEnv.BIKKO_MH_ACCESS_CODE },
  }));
  assert.equal(response.statusCode, 200);
  const cookie = response.multiValueHeaders["set-cookie"][0].split(";")[0];
  return { cookie, response };
}

async function saveCatalog(handler, cookie, catalog, expectedRevision = 0) {
  return handler(request("PUT", "/api/bikko-mh/stock", {
    cookie,
    body: { catalog, expectedRevision },
  }));
}

function catalogWithProduct(name, quantity) {
  return {
    assignments: [{ name, category: "Food", quantity }],
    subcategories: { Chargers: ["USB"] },
    customCategories: [],
  };
}

test("health endpoint works without secrets and does not require a database", async () => {
  const { handler, storeOptions } = createTestApp({ env: {} });
  const response = await handler(request("GET", "/api/healthz"));
  assert.equal(response.statusCode, 200);
  assert.deepEqual(responseBody(response), { status: "ok" });
  assert.equal(storeOptions.length, 0);
});

test("login creates a secure session and protected routes reject missing or invalid sessions", async () => {
  const { handler, storeOptions } = createTestApp();
  const denied = await handler(request("GET", "/api/bikko-mh/state"));
  assert.equal(denied.statusCode, 401);

  const wrongOrigin = await handler(request("POST", "/api/bikko-mh/session", {
    body: { code: testEnv.BIKKO_MH_ACCESS_CODE },
    origin: "https://attacker.example",
  }));
  assert.equal(wrongOrigin.statusCode, 403);

  const { cookie, response } = await signIn(handler);
  const cookieHeader = response.multiValueHeaders["set-cookie"][0];
  assert.match(cookieHeader, /HttpOnly/);
  assert.match(cookieHeader, /Secure/);
  assert.match(cookieHeader, /SameSite=Strict/);

  const invalidSession = await handler(request("GET", "/api/bikko-mh/access", {
    cookie: `${cookie}tampered`,
  }));
  assert.equal(invalidSession.statusCode, 401);

  const access = await handler(request("GET", "/api/bikko-mh/access", { cookie }));
  assert.equal(access.statusCode, 200);
  assert.equal(responseBody(access).role, "staff");

  const rewrittenAccess = await handler(request(
    "GET",
    "/.netlify/functions/bikko-mh-api/bikko-mh/access",
    { cookie },
  ));
  assert.equal(rewrittenAccess.statusCode, 200);

  const state = await handler(request("GET", "/api/bikko-mh/state", { cookie }));
  assert.equal(state.statusCode, 200);
  assert.deepEqual(responseBody(state).catalog.assignments, []);
  assert.deepEqual(storeOptions.at(-1), {
    name: "bikko-mh-independent-state",
    consistency: "strong",
  });
});

test("missing Netlify credentials fail explicitly rather than falling back to another API", async () => {
  const { handler } = createTestApp({ env: {} });
  const response = await handler(request("POST", "/api/bikko-mh/session", {
    body: { code: "anything" },
  }));
  assert.equal(response.statusCode, 503);
  assert.match(responseBody(response).error, /not configured/i);
});

test("stock writes use revisions and reject stale updates", async () => {
  const { handler } = createTestApp();
  const { cookie } = await signIn(handler);
  const catalog = catalogWithProduct("Snack", 4);
  const saved = await saveCatalog(handler, cookie, catalog, 0);
  assert.equal(saved.statusCode, 200);
  assert.equal(responseBody(saved).revision, 1);

  const stale = await saveCatalog(handler, cookie, catalogWithProduct("Snack", 8), 0);
  assert.equal(stale.statusCode, 409);

  const state = await handler(request("GET", "/api/bikko-mh/state", { cookie }));
  assert.equal(responseBody(state).catalog.assignments[0].quantity, 4);
});

test("sales atomically decrement stock and cannot oversell across simultaneous requests", async () => {
  const { handler } = createTestApp();
  const { cookie } = await signIn(handler);
  await saveCatalog(handler, cookie, catalogWithProduct("Snack", 1));
  const sale = {
    productName: "Snack",
    category: "Food",
    quantity: 1,
    unitPrice: 2,
    inventoryRef: { productName: "Snack" },
  };

  const responses = await Promise.all([
    handler(request("POST", "/api/bikko-mh/sales", { cookie, body: sale })),
    handler(request("POST", "/api/bikko-mh/sales", { cookie, body: sale })),
  ]);
  assert.deepEqual(responses.map(response => response.statusCode).sort(), [201, 409]);

  const state = responseBody(await handler(request("GET", "/api/bikko-mh/state", { cookie })));
  assert.equal(state.catalog.assignments[0].quantity, 0);
  assert.equal(state.sales.length, 1);
});

test("editing and deleting a tracked sale restores and reapplies the correct quantity", async () => {
  const { handler } = createTestApp();
  const { cookie } = await signIn(handler);
  await saveCatalog(handler, cookie, catalogWithProduct("Snack", 3));

  const created = await handler(request("POST", "/api/bikko-mh/sales", {
    cookie,
    body: {
      productName: "Snack",
      category: "Food",
      quantity: 1,
      unitPrice: 2,
      inventoryRef: { productName: "Snack" },
    },
  }));
  assert.equal(created.statusCode, 201);
  const saleId = responseBody(created).sale.id;

  const edited = await handler(request("PATCH", `/api/bikko-mh/sales/${saleId}`, {
    cookie,
    body: {
      productName: "Snack",
      category: "Food",
      quantity: 2,
      unitPrice: 3,
      inventoryRef: { productName: "Snack" },
      expectedRevision: 2,
    },
  }));
  assert.equal(edited.statusCode, 200);
  assert.equal(responseBody(edited).state.catalog.assignments[0].quantity, 1);

  const deleted = await handler(request("DELETE", `/api/bikko-mh/sales/${saleId}`, {
    cookie,
    body: { expectedRevision: 3 },
  }));
  assert.equal(deleted.statusCode, 200);
  assert.equal(responseBody(deleted).state.catalog.assignments[0].quantity, 3);
  assert.equal(responseBody(deleted).inventoryRestored, true);
});

test("local browser imports are idempotent and remain within this Netlify store", async () => {
  const { handler } = createTestApp();
  const { cookie } = await signIn(handler);
  const imported = {
    catalog: catalogWithProduct("Local item", 5),
    sales: [{
      id: "local-sale-1",
      productName: "Local item",
      category: "Food",
      quantity: 1,
      unitPrice: 5,
      recordedAt: "2026-10-03T10:00:00.000Z",
    }],
  };

  const first = await handler(request("POST", "/api/bikko-mh/import", {
    cookie,
    body: imported,
  }));
  assert.equal(first.statusCode, 200);
  assert.equal(responseBody(first).importedSales, 1);
  assert.equal(responseBody(first).state.revision, 1);

  const second = await handler(request("POST", "/api/bikko-mh/import", {
    cookie,
    body: imported,
  }));
  assert.equal(second.statusCode, 200);
  assert.equal(responseBody(second).importedSales, 0);
  assert.equal(responseBody(second).state.revision, 1);
});